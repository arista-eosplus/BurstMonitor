TODO
# TODO speed change requires restart

"shut|no shut daemon" on upgrade